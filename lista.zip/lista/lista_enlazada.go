package lista

type nodoLista[T any] struct {
	dato      T
	siguiente *nodoLista[T]
}

type listaEnlazada[T any] struct {
	primero *nodoLista[T]
	ultimo  *nodoLista[T]
	largo   int
}

type iterListaEnlazada[T any] struct {
	actual   *nodoLista[T]
	anterior *nodoLista[T]
	lista    *listaEnlazada[T]
}

const lista_vacia = "La lista esta vacia"
const panic_iteracion_completada = "El iterador termino de iterar"
const constanteLargoInicial = 0

func nodoCrear[T any](dato T) *nodoLista[T] {
	nodo := new(nodoLista[T])
	nodo.dato = dato
	return nodo
}

func CrearListaEnlazada[T any]() Lista[T] {
	lista := new(listaEnlazada[T])
	lista.largo = constanteLargoInicial
	return lista
}

func (lista listaEnlazada[T]) EstaVacia() bool {
	return lista.largo == constanteLargoInicial
}

func (lista *listaEnlazada[T]) InsertarPrimero(elem T) {
	nuevo := nodoCrear(elem)
	if lista.EstaVacia() {
		lista.ultimo = nuevo
	} else {
		nuevo.siguiente = lista.primero
	}
	lista.primero = nuevo
	lista.largo++
}

func (lista *listaEnlazada[T]) InsertarUltimo(elem T) {
	nuevo := nodoCrear(elem)
	if lista.EstaVacia() {
		lista.primero = nuevo
	} else {
		lista.ultimo.siguiente = nuevo
	}
	lista.ultimo = nuevo
	lista.largo++
}

func (lista *listaEnlazada[T]) BorrarPrimero() T {
	if lista.EstaVacia() {
		panic(lista_vacia)
	}
	eliminado := lista.primero.dato
	lista.primero = lista.primero.siguiente
	if lista.primero == nil {
		lista.ultimo = nil
	}
	lista.largo--
	return eliminado
}

func (lista listaEnlazada[T]) VerPrimero() T {
	if lista.EstaVacia() {
		panic(lista_vacia)
	}
	return lista.primero.dato
}

func (lista listaEnlazada[T]) VerUltimo() T {
	if lista.EstaVacia() {
		panic(lista_vacia)
	}
	return lista.ultimo.dato
}

func (lista listaEnlazada[T]) Largo() int {
	return lista.largo
}

func (lista listaEnlazada[T]) Iterar(visitar func(T) bool) {
	actual := lista.primero
	for actual != nil {
		if !visitar(actual.dato) {
			return
		}
		actual = actual.siguiente
	}
}

func (lista *listaEnlazada[T]) Iterador() IteradorLista[T] {
	iterador := new(iterListaEnlazada[T])
	iterador.actual = lista.primero
	iterador.anterior = nil
	iterador.lista = lista
	return iterador
}

func (iter iterListaEnlazada[T]) HaySiguiente() bool {
	return iter.actual != nil
}

func (iter *iterListaEnlazada[T]) Siguiente() {
	if !iter.HaySiguiente() {
		panic(panic_iteracion_completada)
	}
	iter.anterior = iter.actual
	iter.actual = iter.actual.siguiente
}

func (iter iterListaEnlazada[T]) VerActual() T {
	if !iter.HaySiguiente() {
		panic(panic_iteracion_completada)
	}
	return iter.actual.dato
}

func (iter *iterListaEnlazada[T]) Borrar() T {
	if !iter.HaySiguiente() {
		panic(panic_iteracion_completada)
	}
	eliminado := iter.actual.dato

	if iter.anterior == nil {
		iter.lista.primero = iter.actual.siguiente
	} else {
		iter.anterior.siguiente = iter.actual.siguiente
	}
	if iter.actual == iter.lista.ultimo {
		iter.lista.ultimo = iter.anterior
	}
	iter.actual = iter.actual.siguiente
	iter.lista.largo--
	return eliminado
}

func (iter *iterListaEnlazada[T]) Insertar(elem T) {
	nuevo := nodoCrear(elem)

	if iter.anterior == nil {
		nuevo.siguiente = iter.lista.primero
		iter.lista.primero = nuevo
		if iter.lista.largo == 0 {
			iter.lista.ultimo = nuevo
		}
	} else {
		nuevo.siguiente = iter.actual
		iter.anterior.siguiente = nuevo
		if iter.actual == nil {
			iter.lista.ultimo = nuevo
		}
	}
	iter.actual = nuevo
	iter.lista.largo++
}
